<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
 
     <!-- Site Metas -->
    <title>Mr. Clean - Housekeeping, cleaning, Manpower, Homecare</title>  
    <meta name="keywords" content=" nearby,silvassa,dadra and nagar haveli, DNH ">
    <meta name="description" content="mr clean is the most trusted brand in market for cleaning, house keeping and Manpower services. We are providing cleaning services and house keeping services
                                      for industries and residential societies	">
    <meta name="author" content="Ramesh solanki">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Colors CSS -->
    <link rel="stylesheet" href="css/colors.css">
    <!-- ALL VERSION CSS -->
    <link rel="stylesheet" href="css/versions.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!-- Modernizer for Portfolio -->
    <script src="js/modernizer.js"></script>


</head>
<body class="realestate_version">

    <!-- LOADER -->
    <div id="preloader">
        <span class="loader"><span class="loader-inner"></span></span>
    </div><!-- end loader -->
    <!-- END LOADER -->

    <header class="header header_style_01">
        <nav class="megamenu navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">  <h1> <img src="images/logos/logo.png" width ="60" alt="image"> MR. CLEAN <small>House keeping & Cleaning </small> </h1> </a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a class="active" href="index.php">Home</a></li>
                        <li><a href="service.php">Services</a></li>
                        <li><a href="gallery.php">Image Gallery</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li class="social-links"><a href="#"><i class="fa fa-facebook global-radius"></i></a></li>
                        <li class="social-links"><a href="#"><i class="fa fa-instagram global-radius"></i></a></li>
                        <li class="social-links"><a href="#"><i class="fa fa-twitter global-radius"></i></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

	
	<ul class='slideshow'>
		<li>
			<span>Cleaning</span>
		</li>
		<li>		
			<span>House keeping</span>
		</li>
		<li>		
			<span>Manpower supplier</span>
		</li>
		<li>
			<span>House keeping material</span>
		</li>
	</ul>
	
    <div class="parallax first-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6 wow slideInLeft hidden-xs hidden-sm">
                    <div class="contact_form">
                        <h3><i class="fa fa-envelope-o grd1 global-radius"></i> REQUEST FOR CALL BACK</h3>
                        <form id="contactform1" class="row" name="contactform" method="post">
                            <fieldset class="row-fluid">
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" name="first_name1" id="first_name1" class="form-control" placeholder="First Name">
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" name="phone1" id="phone1" class="form-control" placeholder="Your Phone">
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <input type="email" name="email1" id="email1" class="form-control" placeholder="Your Email">
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
                                    <input type="submit" name="SEND" value ="REQUEST CALL BACK" id="submit1" class="btn btn-light btn-radius btn-brd grd1 btn-block" />
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div>
				<div class="col-md-6 col-sm-12">
                    <div class="big-tagline clearfix">
                        <h2>MR. CLEAN</h2>
                        <p class="lead">House keeping & Cleaning services </p>
                        <a data-scroll href="#gallery" class="btn btn-light btn-radius grd1 btn-brd">View Gallery</a>
                    </div>
                </div>
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section -->
	
	<div class="about-box">
		<div class="container">
			<div class="row">
				<div class="top-feature owl-carousel owl-theme">
					<div class="item">
						<div class="single-feature">
							<div class="icon"><img src="icon/cleaner.png" class="img-responsive" alt=""></div>
							<h4><a href="#">CLEANING</a></h4>
							<p>We are working for cleaning and hygiene of industrial premises. </p>
						</div> 
					</div>
					<div class="item">
						<div class="single-feature">
							<div class="icon"><img src="icon/cleaner.png" class="img-responsive" alt=""></div>
							<h4><a href="#">HOUSE KEEPING</a></h4>
							<p>We are following best in class house keeping  practices.</p>
						</div> 
					</div>
					<div class="item">
						<div class="single-feature">
							<div class="icon"><img src="icon/cleaner.png" class="img-responsive" alt=""></div>
							<h4><a href="#">MANPOWER SUPPLIER</a></h4>
							<p>We are supplying skilled and unskilled manpower to industries </p>
						</div> 
					</div>
					<div class="item">
						<div class="single-feature">
							<div class="icon"><img src="icon/cleaner.png" class="img-responsive" alt=""></div>
							<h4><a href="#">HOUSE KEEPING MATERIAL SUPPLIER</a></h4>
							<p>One of the leading house keeping material supplier. </p>
						</div> 
					</div>
					<div class="item">
						<div class="single-feature">
							<div class="icon"><img src="icon/cleaner.png" class="img-responsive" alt=""></div>
							<h4><a href="#">HOME CARE PRODUCTS</a></h4>
							<p>Providing wide range of house care products. </p>
						</div> 
					</div>

				</div>
			</div>
			
			<hr class="hr1">
			
			<div class="row">
				<div class="col-md-6">
                    <div class="post-media wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
                         <img src="images/clean.png" alt="" class="img-responsive">                       
                    </div><!-- end media -->
                </div>
				<div class="col-md-6">
					<div class="message-box right-ab">
                        <h4>Most trusted Cleaning Products & Services</h4>
                        <h2>Welcome to Mr. CLEAN</h2>
                        <p><b>MR. CLEAN </b> is most trusted in brand in fitness and nutrition field.</p>
						<p> We are working for Cleaning, house keeping and manpower services to industries. we have helped thousands of our clients with care and respect.
                             We have highly positive response from industries. </p>
							 <p>MR. CLEAN Industrial/commercial housekeeping and cleaning is more than just about cleaning your premises. We aim to create healthy and clean workplaces
							 that your employees and customers would love to be in. We are following best in class cleaning practices to improve productivity, overall well-being, and health of employees is to offer them a clean and hygienic place to work  </p>
						<a href="services.php" class="btn btn-light btn-radius grd1 btn-brd"> Read More </a>
                    </div>
				</div>
			</div>
			
		</div>
	</div>

<!---
    <div id="agent" class="parallax section db parallax-off" style="background-image:url('uploads/parallax_02.png');">
        <div class="container">
            <div class="section-title row text-center">
                <div class="col-md-12 ">
                    <h3>Expert consultant</h3>
                    <p class="lead">Highly energetic and expert coach will motivate and energize you to achieve your fitness goal .</p>
                </div><!-- end col --
            </div><!-- end title --

            <div class="row">
                <div class="col-md-5">
                    <div class="message-box">
                        <h4>Meet your coaches</h4>
                        <h3>Ashish Malhotra <small>(specially for boys and males)</small></h3>
						<h3>Alpa Malhotra <small>(specially for kids, girls and women’s)</small></h3>
                        <p class="lead">We are a wellness coaches helping people to live a Healthy active lifestyle for last 5 years
                        Tell us your goal and we will help you to achieve it.See our client testimonials.</p>


                        <p> As a fitness coach i have so many achievements and Awards. </p>
						 <!--- <h4>ACHIEVEMENTS</h4>
						<ol>
						     <li> Award </li>
							 <li> Award </li>
							 <li> Award </li>
							 <li> Award </li>
						</ol>   --

                        <a href="contact.php" data-scroll class="btn btn-light global-radius btn-brd grd1 effect-1">Contact Me</a>
                    </div><!-- end messagebox --
                </div><!-- end col --
				<div class="col-md-4">
                    <div class="post-media wow fadeIn">
                        <img src="uploads/coach.jpg" alt="" class="img-responsive">
                    </div><!-- end media --
                </div><!-- end col --
                <div class="col-md-3">
                    <div class="agencies_meta clearfix">
                        <span><i class="fa fa-envelope "></i> <a href="mailto:ashishmalhotra543@gmail.com">ashishmalhotra543@gmail.com</a></span>
                        <span><i class="fa fa-phone-square "></i> 9979458122</span>
						<span><i class="fa fa-phone-square "></i> 8000081405</span>
                        <span><i class="fa fa-facebook-square "></i> <a href="https://www.facebook.com/ashish.malhotra.1428" target = "_blank">facebook</a></span>
						<span><i class="fa fa-linkedin-square "></i> <a href="https://www.instagram.com/ashish_level10" target = "_blank">Instagrame</a></span>

                        
                    </div><!-- end agencies_meta --
                </div><!-- end col --
            </div><!-- end row --
        </div>
    </div>     --->

    <div id="testimonials" class="section lb">
        <div class="container">
            <div class="section-title row text-center">
                <div class="col-md-8 col-md-offset-2">
                    <h3>Happy Customers</h3>
                    <p class="lead">What our valuable customer speaking about us.</p>
                </div><!-- end col -->
            </div><!-- end title -->

            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="testi-carousel owl-carousel owl-theme">
                        <div class="testimonial clearfix">
                            <div class="desc">
                                <h3><i class="fa fa-quote-left"></i> Wonderful Services! <i class="fa fa-quote-right"></i></h3>
                                <p class="lead">Mr. Clean having expertise in Cleaning services.</p>
								
                            </div>
                            <div class="testi-meta">
                                <h4>Ramesh Solanki </h4>
                            </div>
                            <!-- end testi-meta -->
                        </div>
                        <!-- end testimonial -->
						                        <div class="testimonial clearfix">
                            <div class="desc">
                                <h3><i class="fa fa-quote-left"></i> Excellent Services! <i class="fa fa-quote-right"></i></h3>
                                <p class="lead">Mr. Clean providing awesome services.</p>
								
                            </div>
                            <div class="testi-meta">
                                <h4>Kundan </h4>
                            </div>
                            <!-- end testi-meta -->
                        </div>
                        <!-- end testimonial -->
						                        <div class="testimonial clearfix">
                            <div class="desc">
                                <h3><i class="fa fa-quote-left"></i> Expert team! <i class="fa fa-quote-right"></i></h3>
                                <p class="lead">Team having expertise in cleaning services.</p>
								
                            </div>
                            <div class="testi-meta">
                                <h4>Vimal patel </h4>
                            </div>
                            <!-- end testi-meta -->
                        </div>
                        <!-- end testimonial -->

                    </div><!-- end carousel -->
                </div><!-- end col -->
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section -->

<?php include "php/footer.php"; ?>

    <!-- ALL JS FILES -->
    <script src="js/all.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/custom.js"></script>
    <script src="js/portfolio.js"></script>
    <script src="js/hoverdir.js"></script>    
    <script src="http://maps.googleapis.com/maps/api/js?sensor=false&amp;libraries=places"></script>
   <!-- MAP & CONTACT -->
    <script src="js/map.js"></script>

</body>
</html>