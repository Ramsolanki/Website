<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
 
     <!-- Site Metas -->
    <title>Mr. Clean - Housekeeping, cleaning, Manpower, Homecare</title>  
    <meta name="keywords" content=" nearby,silvassa,dadra and nagar haveli, DNH ">
    <meta name="description" content="mr clean is the most trusted brand in market for cleaning, house keeping and Manpower services. We are providing cleaning services and house keeping services
                                      for industries and residential societies	">
    <meta name="author" content="Ramesh solanki">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Colors CSS -->
    <link rel="stylesheet" href="css/colors.css">
    <!-- ALL VERSION CSS -->
    <link rel="stylesheet" href="css/versions.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!-- Modernizer for Portfolio -->
    <script src="js/modernizer.js"></script>


</head>
<body class="realestate_version">

    <!-- LOADER -->
    <div id="preloader">
        <span class="loader"><span class="loader-inner"></span></span>
    </div><!-- end loader -->
    <!-- END LOADER -->

   <header class="header header_style_01">
        <nav class="megamenu navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><h1> <img src="images/logos/logo.png" width ="60" alt="image"> MR. CLEAN <small>House keeping & Cleaning </small> </h1> <!---<img src="images/logos/logo.png" alt="image"> --></a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="service.php">Services</a></li>
                        <li><a href="gallery.php">Image Gallery</a></li>
                        <li><a class="active" href="contact.php">Contact</a></li>
                        <li class="social-links"><a href="#"><i class="fa fa-facebook global-radius"></i></a></li>
                        <li class="social-links"><a href="#"><i class="fa fa-instagram global-radius"></i></a></li>
                        <li class="social-links"><a href="#"><i class="fa fa-twitter global-radius"></i></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
	
	<div class="all-title-box">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2>Contact</h2>
					<!-- Breadcrumbs -->
					<nav id="breadcrumbs">
						<ul>
							<li><a href="#">Home</a></li>
							<li>Contact</li>
						</ul>
					</nav>
				</div>
			</div>
		</div>
	</div>
	
	<div id="support" class="section wb">
        <div class="container">
            <div class="section-title text-center">
                <h3>Request for Contact</h3>
                <p class="lead">Please fill out the form below. <br>To get Quote and Details of products and services!</p>
            </div><!-- end title -->

            <div class="row">
                <div class="col-md-6">
				
				<?php


if (isset($_POST['submit'])) 
{



$first_name     = $_POST['first_name'];
$last_name     = $_POST['last_name'];
$email    = $_POST['email'];
$phone   = $_POST['phone'];
$city   = $_POST['city'];
$comments  = $_POST['comments'];
/* $verify   = $_POST['verify'];  */




// Configuration option.
// Enter the email address that you want to emails to be sent to.
// Example $address = "joe.doe@yourdomain.com";

//$address = "example@themeforest.net";
$address = "mrcleanservices9@gmail.com";


// Configuration option.
// i.e. The standard subject will appear as, "You've been contacted by John Doe."

// Example, $e_subject = '$name . ' has contacted you via Your Website.';

$subject = 'You\'ve been contacted by ' . $first_name . '.';


// Configuration option.
// You can change this if you feel that you need to.
// Developers, you may wish to add more fields to the form, in which case you must be sure to add them here.

 $body = "You have been contacted by $first_name. $first_name is interested in $interest, their additional informations is as follows " ;
 $body .= "Email :- $email" ;
	
	
/*$e_content = "\"$comments\"" . PHP_EOL; */
$e_reply = "You can contact $first_name via email, $email or via phone $phone";


       $from="From: $name<$email>\r\nReturn-path: $email";
       $customer = "You have been contacted by $first_name. $first_name is interested in $interest, their additional informations is as follows \n" ;
       
       $customer .= "Name - $first_name.$last_name  \n" ;
 $customer .= "Email - $email   ,   Mobile No. - $phone \n";
 $customer .= "Location - $city , $state \n";
 $customer .= "Query/Feedback , - $comments \n";
	   $message = $customer."\n\n"."About Goal:- \n".$comments;
	   
        $sent = mail("ramsolanki500@gmail.com", $subject, $message, $from);
        
        if ($sent == true)
		{
        $mail_success = "Successfully:- Your query sent to MR. CLEAN!";
		}
		else{
		$mail_fail = "Failure:- Your query not sent to MR. CLEAN!";
		};



	// Email has sent successfully, echo a success page.


 

}

unset($_POST);

?>

				<div style = "color:#00cc00;"> 
	                   <p><span style = "color:#00cc00;"><?php if (isset($mail_success)) { echo $mail_success;} ?></span></p>
				</div>
	            <div style = "color:red;"> 
                       <p><span style = "color:red;" ><?php if (isset($mail_fail)) { echo $mail_fail; } ?></span></p>
	                  <?php unset($mail_success);
	                  unset($mail_fail);?>
				</div>

				
				
				
                    <div class="contact_form">
                        <div id="message"></div>
                        <form id="contactform" class="row" action="contact-process.php" name="contactform" method="post" novalidate="novalidate">
                            <fieldset class="row-fluid">
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" name="first_name" id="first_name" class="form-control" placeholder="First Name">
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" name="last_name" id="last_name" class="form-control" placeholder="Last Name">
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <input type="email" name="email" id="email" class="form-control" placeholder="Your Email">
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" name="phone" id="phone" class="form-control" placeholder="Your Phone">
                                </div>

                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <input type="text" name="city" id="city" class="form-control" placeholder="Enter City/Area">
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <textarea class="form-control" name="comments" id="comments" rows="6" placeholder="Requirement/Query/Feedback/Quotation.."></textarea>
                                </div>
								
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
                                    <input type="submit" value="Get Appointment" id="submit" class="btn btn-primary btn-block btn-large"/>
                                </div>
                            </fieldset>
                        </form>
                    </div>
                </div><!-- end col -->
				<div class="col-md-6">
					<div class="right-box-contact">
						<h4>Phone</h4>
						<div class="support-info">
							<div class="info-title">
								<i class="fa fa-phone" aria-hidden="true"></i>
								+91 9824103552 <br>
								+91 9824103552
								<span>Office Time: 09:00 AM To 09:00 PM </span>
							</div>
						</div>
					</div>
					<div class="right-box-contact">
						<h4>Address</h4>
						<div class="support-info">
							<div class="info-title">
								<i class="fa fa-map-marker" aria-hidden="true"></i>
								<span>Shop No.-150, Landmark business hub, Tokarkhada, Silvassa, Dadra and Nagar Haveli - 396230</span>
							</div>
						</div>
					</div>
					<div class="right-box-contact">
						<h4>Your Feedback</h4>
						<div class="support-info">
							<div class="info-title">
								<i class="fa fa-envelope" aria-hidden="true"></i>
								mrcleanservices9@gmail.com
								<span>Help Us to Improve!</span>
							</div>
						</div>
					</div>
					<div class="right-box-contact">
					
					</div>
				</div><!-- end col -->
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section -->

	<!-- <div id="map"></div>  --
<section>
<div class ="container">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3742.738351383753!2d73.00330281395149!3d20.26968331863487!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be0cbf293854e01%3A0x7d186e055811da96!2sLEVEL10+HERBALIFE+NUTRITION+AND+FITNESS+STUDIO!5e0!3m2!1sen!2sin!4v1538398022778" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</div>
</section>
-->

<?php include "php/footer.php"; ?>

    <!-- ALL JS FILES -->
    <script src="js/all.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/custom.js"></script>
    <script src="js/portfolio.js"></script>
    <script src="js/hoverdir.js"></script>    
    <script src="http://maps.googleapis.com/maps/api/js?sensor=false&amp;libraries=places"></script>
   <!-- MAP & CONTACT -->
    <script src="js/map.js"></script>

</body>
</html>