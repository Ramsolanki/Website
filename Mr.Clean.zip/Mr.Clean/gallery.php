<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
 
     <!-- Site Metas -->
    <title>Mr. Clean - Housekeeping, cleaning, Manpower, Homecare</title>  
    <meta name="keywords" content=" nearby,silvassa,dadra and nagar haveli, DNH ">
    <meta name="description" content="mr clean is the most trusted brand in market for cleaning, house keeping and Manpower services. We are providing cleaning services and house keeping services
                                      for industries and residential societies	">
    <meta name="author" content="Ramesh solanki">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Colors CSS -->
    <link rel="stylesheet" href="css/colors.css">
    <!-- ALL VERSION CSS -->
    <link rel="stylesheet" href="css/versions.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!-- Modernizer for Portfolio -->
    <script src="js/modernizer.js"></script>


</head>
<body class="realestate_version">

    <!-- LOADER -->
    <div id="preloader">
        <span class="loader"><span class="loader-inner"></span></span>
    </div><!-- end loader -->
    <!-- END LOADER -->

   <header class="header header_style_01">
        <nav class="megamenu navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><h1> <img src="images/logos/logo.png" width ="60" alt="image"> MR. CLEAN <small>House keeping & Cleaning </small> </h1> <!---<img src="images/logos/logo.png" alt="image"> --></a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="service.php">Services</a></li>
                        <li><a class="active" href="gallery.php">Image Gallery</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li class="social-links"><a href="#"><i class="fa fa-facebook global-radius"></i></a></li>
                        <li class="social-links"><a href="#"><i class="fa fa-instagram global-radius"></i></a></li>
                        <li class="social-links"><a href="#"><i class="fa fa-twitter global-radius"></i></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
	
	<div class="all-title-box">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2>Gallery</h2>
					<!-- Breadcrumbs -->
					<nav id="breadcrumbs">
						<ul>
							<li><a href="#">Home</a></li>
							<li>Gallery</li>
						</ul>
					</nav>
				</div>
			</div>
		</div>
	</div>
	
	<div id="gallery" class="section wb">        
        <div class="container">
            <div class="section-title row text-center">
                <div class="col-md-8 col-md-offset-2">
                    <h3>Photo Gallery</h3>
                    <p class="lead">Photos of Events and Projects</p>
                </div><!-- end col -->
            </div><!-- end title -->

            <div id="da-thumbs" class="da-thumbs portfolio">
                <div class="post-media_g pitem item-w1 item-h1 cat1">
                    <a href="uploads/1.jpg" data-rel="prettyPhoto[gal]">
                        <img src="uploads/1.jpg" alt="" class="img-responsive">
                        <div>
                            <i class="flaticon-unlink"></i>
                        </div>
                    </a>
                </div>
                <div class="post-media_g pitem item-w1 item-h1 cat2">
                    <a href="uploads/2.jpg" data-rel="prettyPhoto[gal]">
                        <img src="uploads/2.jpg" alt="" class="img-responsive">
                        <div>
                            <i class="flaticon-unlink"></i>
                        </div>
                    </a>
                </div>
                <div class="post-media_g pitem item-w1 item-h1 cat1">
                    <a href="uploads/3.jpg" data-rel="prettyPhoto[gal]">
                        <img src="uploads/3.jpg" alt="" class="img-responsive">
                        <div>
                            <i class="flaticon-unlink"></i>
                        </div>
                    </a>
                </div>

                <div class="post-media_g pitem item-w1 item-h1 cat3">
                    <a href="uploads/4.jpg" data-rel="prettyPhoto[gal]">
                        <img src="uploads/4.jpg" alt="" class="img-responsive">
                        <div>
                            <i class="flaticon-unlink"></i>
                        </div>
                    </a>
                </div>
                <div class="post-media_g pitem item-w1 item-h1 cat2">
                    <a href="uploads/5.jpg" data-rel="prettyPhoto[gal]">
                        <img src="uploads/5.jpg" alt="" class="img-responsive">
                        <div>
                            <i class="flaticon-unlink"></i>
                        </div>
                    </a>
                </div>
                <div class="post-media_g pitem item-w1 item-h1 cat1">
                    <a href="uploads/6.jpg" data-rel="prettyPhoto[gal]">
                        <img src="uploads/6.jpg" alt="" class="img-responsive">
                        <div>
                            <i class="flaticon-unlink"></i>
                        </div>
                    </a>
                </div>
            </div><!-- end portfolio -->
        </div><!-- end container -->
    </div><!-- end section -->



<?php include "php/footer.php"; ?>

    <!-- ALL JS FILES -->
    <script src="js/all.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/custom.js"></script>
    <script src="js/portfolio.js"></script>
    <script src="js/hoverdir.js"></script>    
    <script src="http://maps.googleapis.com/maps/api/js?sensor=false&amp;libraries=places"></script>
   <!-- MAP & CONTACT -->
    <script src="js/map.js"></script>

</body>
</html>