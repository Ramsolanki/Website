<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
 
     <!-- Site Metas -->
    <title>Mr. Clean - Housekeeping, cleaning, Manpower, Homecare</title>  
    <meta name="keywords" content=" nearby,silvassa,dadra and nagar haveli, DNH ">
    <meta name="description" content="mr clean is the most trusted brand in market for cleaning, house keeping and Manpower services. We are providing cleaning services and house keeping services
                                      for industries and residential societies	">
    <meta name="author" content="Ramesh solanki">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Colors CSS -->
    <link rel="stylesheet" href="css/colors.css">
    <!-- ALL VERSION CSS -->
    <link rel="stylesheet" href="css/versions.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!-- Modernizer for Portfolio -->
    <script src="js/modernizer.js"></script>


</head>
<body class="realestate_version">

    <!-- LOADER -->
    <div id="preloader">
        <span class="loader"><span class="loader-inner"></span></span>
    </div><!-- end loader -->
    <!-- END LOADER -->

    <header class="header header_style_01">
        <nav class="megamenu navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><h1> <img src="images/logos/logo.png" width ="60" alt="image"> MR. CLEAN <small>House keeping & Cleaning </small> </h1> <!---<img src="images/logos/logo.png" alt="image"> --></a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="index.php">Home</a></li>
                        <li><a class="active" href="service.php">Services</a></li>
                        <li><a href="gallery.php">Image Gallery</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li class="social-links"><a href="#"><i class="fa fa-facebook global-radius"></i></a></li>
                        <li class="social-links"><a href="#"><i class="fa fa-instagram global-radius"></i></a></li>
                        <li class="social-links"><a href="#"><i class="fa fa-twitter global-radius"></i></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
	
	<div class="all-title-box">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2>Services</h2>
					<!-- Breadcrumbs -->
					<nav id="breadcrumbs">
						<ul>
							<li><a href="#">Home</a></li>
							<li>Services</li>
						</ul>
					</nav>
				</div>
			</div>
		</div>
	</div>
	
	<div class="about-box">
		<div class="container">
			<div class="section-title row text-center">
                <div class="col-md-8 col-md-offset-2">
                    <h3>OUR SERVICES</h3>
                    <p>We have expertise in field of Cleaning and House keeping.  </p>
                </div><!-- end col -->
            </div><!-- end title -->
			
			<div class="row">
				<div class="col-md-4 col-sm-4 col-sm-12">
					<div class="single-services">
						<div class="single-services-img">
							<img src="images/cleaning-12.jpg" class="img-responsive" alt="">
						</div>
						<div class="single-services-desc">
							<h4><a href="#">Cleaning/House keeping</a></h4>
							<p>MR. CLEAN commercial housekeeping and cleaning is more than just about cleaning your premises. We aim to create healthy and clean workplaces that your employees and customers would love to be in.</p>
							<p><b> Commercial Services </b> </p>
							<ol>
							    <li>Cleaning</li>
								<li>Deep Cleaning</li>
								<li>Annual housekeeping</li>
								<li>Window cleaning</li>
								<li>Carpet and chair cleaning</li>
								<li>Commercial plumbing</li>
								<li>Commercial electrical</li>
								<li>Indoor plants for hire</li>
							</ol>
						</div>

                    </div>
				</div>

				<div class="col-md-4 col-sm-4 col-sm-12">
					<div class="single-services">
						<div class="single-services-img">
							<img src="images/cleaning-7.jpg" class="img-responsive" alt="">
						</div>
						<div class="single-services-desc">
							<h4><a href="#">House keeping material</a></h4>
							<p>Cleaning house means cleaning surfaces like floors, walls, windows, rugs and appliances. Except for rugs and upholstery, most household surfaces are “hard.” Technically, household cleaning is “hard surface cleaning.”</p>
						    <p> We are providing following home care products </p>
							<ul>
							<li>Toilet Cleaner</li>
							<li>Glass Cleaner</li>
							<li>Air freshener</li>
							<li>Rose Phenyle </li>
							<li>Home Cleaning Products</li>
							<li>Rose Phenyle</li>
							<li>Floor Cleaner</li>
							<li>Jasmine Phenyle</li>
							<li>Broom</li>
							<li>Mope</li>
							<li>Brush</li>
							<li>Bucket</li>
							<li>Dust bin</li>

							</ul>
							
							
						</div>

                    </div>
				</div>
				<div class="col-md-4 col-sm-4 col-sm-12">
					<div class="single-services">
						<div class="single-services-img">
							<img src="images/manpower-55.png" class="img-responsive" alt="">
						</div>
						<div class="single-services-desc">
							<h4><a href="#">Manpower Supplier</a></h4>
							<p>MR. CLEAN is also engaged in offering customized solutions for all types of manpower services. We are offering a wide range of qualified human resources across the industries for all types of projects. The company has distinguished itself as a quality manpower solution provider at cost-effective prices through a well-managed management set up.</p>
						</div>

                    </div>
				</div>
				
			</div>

			
		</div>
	</div>
		
		

			

			




<?php include "php/footer.php"; ?>

    <!-- ALL JS FILES -->
    <script src="js/all.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/custom.js"></script>
    <script src="js/portfolio.js"></script>
    <script src="js/hoverdir.js"></script>    
    <script src="http://maps.googleapis.com/maps/api/js?sensor=false&amp;libraries=places"></script>
   <!-- MAP & CONTACT -->
    <script src="js/map.js"></script>

</body>
</html>