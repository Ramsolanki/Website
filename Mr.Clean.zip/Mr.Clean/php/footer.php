    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="widget clearfix">
                        <div class="widget-title">
                            <h3> Youtube channel </h3>
                        </div>
                        <p>Video</p>
                        
                    </div><!-- end clearfix -->
                </div><!-- end col -->

                <div class="col-md-3 col-sm-3 col-xs-12">
                    <div class="widget clearfix">
                        <div class="widget-title">
                            <h3>Info Link</h3>
                        </div>

                        <ul class="twitter-widget footer-links">
                            <li><a href="index.php"> Home </a></li>
                            <li><a href="service.php"> Services</a></li>
							<li><a href="gallery.php"> Gallery</a></li>
							<li><a href="contact.php"> Contact</a></li>
                        </ul><!-- end links -->
                    </div><!-- end clearfix -->
                </div><!-- end col -->
				
				<div class="col-md-3 col-sm-3 col-xs-12">
                    <div class="widget clearfix">
                        <div class="widget-title">
                            <h3>Contact Details</h3>
                        </div>

                        <ul class="footer-links">
                            <li><a href="mailto:mrcleanservices9@gmail.com">mrcleanservices9@gmail.com</a></li>
                            <li>SHOP NO. - 150, LANDMARK BUSINESS HUB, TOKARKHADA, SILVASSA, DADRA & NAGAR HAVELI - 396230</li>
                            <li>+91 9824103552</li>
							<li>+91 9824103552</li>
                        </ul><!-- end links -->
                    </div><!-- end clearfix -->
                </div><!-- end col -->
				
                <div class="col-md-2 col-sm-2 col-xs-12">
                    <div class="widget clearfix">
                        <div class="widget-title">
                            <h3>Social</h3>
                        </div>
                        <ul class="footer-links">
                            <li><a href="https://www.facebook.com" target = "_blank"><i class="fa fa-facebook"></i> Facebook</a></li>
							<li><a  href="https://www.instagram.com" target = "_blank"><i class="fa fa-instagram"></i> Instagram</a></li>
                            
                        </ul><!-- end links -->
                    </div><!-- end clearfix -->
                </div><!-- end col -->
				
            </div><!-- end row -->
        </div><!-- end container -->
    </footer><!-- end footer -->

    <div class="copyrights">
        <div class="container">
            <div class="footer-distributed">
                <div class="footer-left">
                    <p class="footer-company-name"><a href="https://mrcleanservices.in">MR. CLEAN </a> All Rights Reserved. &copy; 2020 </p>
                </div>

                <div class="footer-right">
                    <p class="footer-company-name">Design By : <a href="https://angelinnovations.in" target = "_blank" >Angel innovations</a> 
                </div>
            </div>
        </div><!-- end container -->
    </div> <!-- end copyrights -->

    <a href="#" id="scroll-to-top" class="dmtop global-radius"><i class="fa fa-angle-up"></i></a>