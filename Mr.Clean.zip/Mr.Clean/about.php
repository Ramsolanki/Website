<!DOCTYPE html>
<html lang="en">

    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
 
     <!-- Site Metas -->
    <title>Level10- Nutrition and Fitness</title>  
    <meta name="keywords" content="weight loss, fitness,kids nutrition, personal care, fitness coach, health, metal fitness, wellness, wellness coach,  nutrition, workout, yoga, weight loss in silvassa, fitness in silvassa, work from home, extra income, business opportunity, nearby,silvassa,dadra and nagar haveli, DNH, vapi  ">
    <meta name="description" content="LEvel10 is the most trusted brand in market for fitness and nutrition. We are providing wellness services for weight loss, nutrition,
                                      kids nutrition, health, fitness, yoga and workout	">
    <meta name="author" content="Ramesh solanki">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon" />
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Colors CSS -->
    <link rel="stylesheet" href="css/colors.css">
    <!-- ALL VERSION CSS -->
    <link rel="stylesheet" href="css/versions.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!-- Modernizer for Portfolio -->
    <script src="js/modernizer.js"></script>

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body class="realestate_version">

    <!-- LOADER -->
    <div id="preloader">
        <span class="loader"><span class="loader-inner"></span></span>
    </div><!-- end loader -->
    <!-- END LOADER -->

    <header class="header header_style_01">
        <nav class="megamenu navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><h1> LEVEL10 <small>Nutrition & Fitness </small> </h1> <!---<img src="images/logos/logo.png" alt="image"> --></a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a  href="index.php">Home</a></li>
                        <li><a class="active"  href="about.php">About us </a></li>
                        <li><a href="service.php">Fitness Services</a></li>
                        <li><a href="gallery.php">Image Gallery</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li class="social-links"><a href="#"><i class="fa fa-facebook global-radius"></i></a></li>
                        <li class="social-links"><a href="#"><i class="fa fa-instagram global-radius"></i></a></li>
                        <li class="social-links"><a href="#"><i class="fa fa-twitter global-radius"></i></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
	
	<div class="all-title-box">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2>About Us</h2>
					<!-- Breadcrumbs -->
					<nav id="breadcrumbs">
						<ul>
							<li><a href="#">Home</a></li>
							<li>About Us</li>
						</ul>
					</nav>
				</div>
			</div>
		</div>
	</div>
	
	<div class="about-box">
		<div class="container">

			
			<hr class="hr1">
			
			<div class="row">
				<div class="col-md-6">
                    <div class="post-media wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
                        <img src="images/about.jpg" alt="" class="img-responsive">                        
                    </div><!-- end media -->
                </div>
				<div class="col-md-6">
					<div class="message-box right-ab">
                        <h4>Most trusted Fitness services</h4>
                        <h2>Welcome to LEVEL10</h2>
                        <p>We are the market leader.</p>
						<p>About our journey as a fitness & Nutrition service provider.</p>
						<p> Our journey started with mission to create a healthy community in the year of 2013.
                           Since then no looking back. In the journey of 5 years we are helping 1000 of people to achieve their health goals.
                           Our branches @ surat, vapi, silvassa and Jamnagar. <br>
                           So lets get started with us <br>
                           Set your goal reach your LEVEL10. <br>
                           BE THE BEST VERSION OF YOURSELF.</p>
						
                    </div>
				</div>
			</div>
			
		</div>
	</div>



<?php include "php/footer.php"; ?>

    <!-- ALL JS FILES -->
    <script src="js/all.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/custom.js"></script>
    <script src="js/portfolio.js"></script>
    <script src="js/hoverdir.js"></script>    
    <script src="http://maps.googleapis.com/maps/api/js?sensor=false&amp;libraries=places"></script>
   <!-- MAP & CONTACT -->
    <script src="js/map.js"></script>

</body>
</html>